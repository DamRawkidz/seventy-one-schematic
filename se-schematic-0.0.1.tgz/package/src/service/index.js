"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.seventyOneService = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
const ts = require("typescript");
const ast_utils_1 = require("../lib/schematics-angular-utils/ast-utils");
const default_path_1 = require("../lib/util/default-path");
// import * as ts from 'typescript';
// import { NodePackageInstallTask,RunSchematicTask } from '@angular-devkit/schematics/tasks';
// import { NodePackageTaskOptions } from '@angular-devkit/schematics/tasks/package-manager/options';
// You don't have to export the function as default. You can also have more than one rule factory
// per file.
function seventyOneService(_options) {
    return (host, _context) => {
        const workspace = getWorkSpace(_options, host);
        _options.project = (_options.project === 'defaultProject') ? workspace.defaultProject : _options.project;
        if (!_options.path) {
            _options.path = default_path_1.makedefaultPath(_options, workspace);
        }
        let files = schematics_1.url('./files');
        const newhost = schematics_1.apply(files, [
            schematics_1.move(_options.path),
            schematics_1.template(Object.assign(Object.assign({}, core_1.strings), _options)),
            specFilter(_options),
            searchFilter(_options),
            autoLoopFilter(_options)
        ]);
        const updateModuleRule = updateRootModule(_options, workspace);
        const templateRule = schematics_1.mergeWith(newhost, schematics_1.MergeStrategy.Default);
        const chainedRule = schematics_1.chain([
            templateRule,
            updateModuleRule
        ]);
        return chainedRule(host, _context);
    };
}
exports.seventyOneService = seventyOneService;
function getWorkSpace(_option, host) {
    const workspec = host.read('/angular.json');
    if (!workspec) {
        throw new schematics_1.SchematicsException('angular.json file not found');
    }
    return JSON.parse(workspec.toString());
}
function updateRootModule(_option, workspace) {
    return (host, _context) => {
        _option.project = (_option.project === 'defaultProject') ? workspace.defaultProject : _option.project;
        const sharedModulePath = `src/app/shared/shared.module.ts`;
        const directiveName = core_1.strings.classify(_option.name);
        const recorder = host.beginUpdate(sharedModulePath);
        if (!_option.skipsearch) {
            const startSource = getAsSourceFile(host, 'src/app/shared/shared.module.ts');
            let importPath = core_1.strings.dasherize(`${_option.path}/search-${_option.name}.directive`);
            const classifyName = `Search${directiveName}Directive`;
            const declarationChanges = ast_utils_1.addDeclarationToModule(startSource, sharedModulePath, classifyName, importPath);
            for (const change of declarationChanges) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
            host.commitUpdate(recorder);
            const source = getAsSourceFile(host, 'src/app/shared/shared.module.ts');
            const exportRecoder = host.beginUpdate(sharedModulePath);
            const exportChange = ast_utils_1.addExportToModule(source, sharedModulePath, classifyName, importPath);
            for (const change of exportChange) {
                if (change.path) {
                    exportRecoder.insertLeft(change.pos, change.toAdd);
                }
            }
            host.commitUpdate(exportRecoder);
        }
        if (!_option.skiploop) {
            const recorder = host.beginUpdate(sharedModulePath);
            const source = getAsSourceFile(host, 'src/app/shared/shared.module.ts');
            const importPathLoop = `${_option.path}/auto-loop-${_option.name}.directive`;
            const classifyNameLoop = `${directiveName}AutoLoopDirective`;
            const changes = ast_utils_1.addDeclarationToModule(source, sharedModulePath, classifyNameLoop, importPathLoop);
            for (const change of changes) {
                recorder.insertLeft(change.pos, change.toAdd);
            }
            host.commitUpdate(recorder);
            const exportSource = getAsSourceFile(host, 'src/app/shared/shared.module.ts');
            const exportRecoder = host.beginUpdate(sharedModulePath);
            const exportChange = ast_utils_1.addExportToModule(exportSource, sharedModulePath, classifyNameLoop, importPathLoop);
            for (const change of exportChange) {
                if (change.path) {
                    exportRecoder.insertLeft(change.pos, change.toAdd);
                }
            }
            host.commitUpdate(exportRecoder);
            // const directiveName =  strings.classify(_option.name)
            // const importContent = `import { ${directiveName}AutoLoopDirective } from './${''}/auto-loop-${directiveName}.directive.ts'; \n`
            // const moduleFiles = getAsSourceFile(host, sharedModulePath)
            // const lastImportEndPos = findlastImportEndPos(moduleFiles)
            // const DeclarationsEndPos = findDeclarationsArray(moduleFiles)
            // const exportEndPos = findExportArray(moduleFiles)
            // rec.insertLeft(lastImportEndPos + 1, importContent)
            // rec.insertLeft(DeclarationsEndPos - 1, `,${directiveName}AutoLoopDirective \n`)
            // rec.insertLeft(exportEndPos - 1, `,${directiveName}AutoLoopDirective \n`)
        }
        return host;
    };
}
function specFilter(_options) {
    if (_options.skiptest) {
        return schematics_1.filter(path => !path.includes('.spec.ts'));
    }
    return schematics_1.noop();
}
function searchFilter(_options) {
    if (_options.skipsearch) {
        return schematics_1.filter(path => !path.includes('search-'));
    }
    return schematics_1.noop();
}
function autoLoopFilter(_options) {
    if (_options.skiploop) {
        return schematics_1.filter(path => !path.includes('loop-'));
    }
    return schematics_1.noop();
}
function getAsSourceFile(host, path) {
    const text = host.read(path);
    if (text === null) {
        throw new schematics_1.SchematicsException('dont find');
    }
    const sourceText = text.toString('utf-8');
    if (!sourceText) {
        throw new schematics_1.SchematicsException(`${path} not found`);
    }
    return ts.createSourceFile(path, sourceText, ts.ScriptTarget.Latest, true);
}
// function findlastImportEndPos(file: ts.SourceFile): number {
//   let pos: number = 0;
//   file.forEachChild((child: ts.Node) => {
//     if (child.kind === ts.SyntaxKind.ImportDeclaration) {
//       pos = child.end
//     }
//   })
//   return pos;
// }
// function findImportArray(file: ts.SourceFile): number {
//   let pos: number = 0;
//   file.forEachChild((node: ts.Node) => {
//     if (node.kind === ts.SyntaxKind.ClassDeclaration) {
//       node.forEachChild((classChild: ts.Node) => {
//         if (classChild.kind === ts.SyntaxKind.Decorator) {
//           classChild.forEachChild((moduleDeclaration: ts.Node) => {
//             moduleDeclaration.forEachChild((objectLitreal: ts.Node) => {
//               objectLitreal.forEachChild((property: ts.Node) => {
//                 if (property.getFullText().includes('imports')) {
//                   pos = property.end
//                 }
//               })
//             })
//           })
//         }
//       })
//     }
//   })
//   return pos
// }
// function findDeclarationsArray(file: ts.SourceFile): number {
//   let pos: number = 0;
//   file.forEachChild((node: ts.Node) => {
//     if (node.kind === ts.SyntaxKind.ClassDeclaration) {
//       node.forEachChild((classChild: ts.Node) => {
//         if (classChild.kind === ts.SyntaxKind.Decorator) {
//           classChild.forEachChild((moduleDeclaration: ts.Node) => {
//             moduleDeclaration.forEachChild((objectLitreal: ts.Node) => {
//               objectLitreal.forEachChild((property: ts.Node) => {
//                 if (property.getFullText().includes('declarations')) {
//                   pos = property.end
//                 }
//               })
//             })
//           })
//         }
//       })
//     }
//   })
//   return pos
// }
// function findExportArray(file: ts.SourceFile): number {
//   let pos: number = 0;
//   file.forEachChild((node: ts.Node) => {
//     if (node.kind === ts.SyntaxKind.ClassDeclaration) {
//       node.forEachChild((classChild: ts.Node) => {
//         if (classChild.kind === ts.SyntaxKind.Decorator) {
//           classChild.forEachChild((moduleDeclaration: ts.Node) => {
//             moduleDeclaration.forEachChild((objectLitreal: ts.Node) => {
//               objectLitreal.forEachChild((property: ts.Node) => {
//                 if (property.getFullText().includes('exports')) {
//                   pos = property.end
//                 }
//               })
//             })
//           })
//         }
//       })
//     }
//   })
//   return pos
// }
//# sourceMappingURL=index.js.map
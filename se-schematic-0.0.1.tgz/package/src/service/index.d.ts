import { Rule } from '@angular-devkit/schematics';
export declare function service(_options: any): Rule;

import { Rule } from '@angular-devkit/schematics';
export declare function seventyOneService(_options: any): Rule;

export declare const makedefaultPath: (option: any, workspace: any) => string;

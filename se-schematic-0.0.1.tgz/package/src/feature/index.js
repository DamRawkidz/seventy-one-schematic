"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.feature = void 0;
const schematics_1 = require("@angular-devkit/schematics");
const core_1 = require("@angular-devkit/core");
// import { InsertChange } from '@schematics/angular/utility/change';
// import ts = require('typescript');
// import { addDeclarationToModule, addExportToModule } from '../lib/schematics-angular-utils/ast-utils';
const default_path_1 = require("../lib/util/default-path");
// You don't have to export the function as default. You can also have more than one rule factory
// per file.
function feature(_options) {
    return (host, _context) => {
        const workspace = getWorkSpace(_options, host);
        _options.project = (_options.project === 'defaultProject') ? workspace.defaultProject : _options.project;
        if (!_options.path) {
            _options.path = default_path_1.makedefaultPath(_options, workspace);
        }
        if (!_options.flat) {
            _options.path = `${_options.path}/${_options.name}`;
        }
        let files = schematics_1.url('./files');
        const newhost = schematics_1.apply(files, [
            schematics_1.move(_options.path),
            schematics_1.template(Object.assign(Object.assign({}, core_1.strings), _options)),
            // specFilter(_options),
            // searchFilter(_options),
            // autoLoopFilter(_options)
        ]);
        // const updateModuleRule = updateRootModule(_options, workspace)
        const templateRule = schematics_1.mergeWith(newhost, schematics_1.MergeStrategy.Default);
        const chainedRule = schematics_1.chain([
            templateRule
        ]);
        return chainedRule(host, _context);
    };
}
exports.feature = feature;
function getWorkSpace(_option, host) {
    const workspec = host.read('/angular.json');
    if (!workspec) {
        throw new schematics_1.SchematicsException('angular.json file not found');
    }
    return JSON.parse(workspec.toString());
}
// function updateRootModule(_option: any, workspace: any) {
//   return (host: Tree, _context: SchematicContext): Tree => {
//     _option.project = (_option.project === 'defaultProject') ? workspace.defaultProject : _option.project
//     const sharedModulePath = `src/app/shared/shared.module.ts`;
//     const directiveName = strings.classify(_option.name)
//     const recorder = host.beginUpdate(sharedModulePath)
//     if (!_option.skipsearch) {
//       const startSource = getAsSourceFile(host, 'src/app/shared/shared.module.ts')
//       let importPath = strings.dasherize(`${_option.path}/search-${_option.name}.directive`)
//       const classifyName = `Search${directiveName}Directive`
//       const declarationChanges = addDeclarationToModule(
//         startSource,
//         sharedModulePath,
//         classifyName,
//         importPath
//       ) as InsertChange[]
//       for (const change of declarationChanges) {
//         recorder.insertLeft(change.pos, change.toAdd);
//       }
//       host.commitUpdate(recorder)
//       const source = getAsSourceFile(host, 'src/app/shared/shared.module.ts')
//       const exportRecoder = host.beginUpdate(sharedModulePath);
//       const exportChange = addExportToModule(
//         source,
//         sharedModulePath,
//         classifyName,
//         importPath
//       ) as InsertChange[];
//       for (const change of exportChange) {
//         if (change.path) {
//           exportRecoder.insertLeft(change.pos, change.toAdd)
//         }
//       }
//       host.commitUpdate(exportRecoder)
//     }
//     if (!_option.skiploop) {
//       const recorder = host.beginUpdate(sharedModulePath)
//       const source = getAsSourceFile(host, 'src/app/shared/shared.module.ts')
//       const importPathLoop = `${_option.path}/auto-loop-${_option.name}.directive`
//       const classifyNameLoop = `${directiveName}AutoLoopDirective`
//       const changes = addDeclarationToModule(
//         source,
//         sharedModulePath,
//         classifyNameLoop,
//         importPathLoop
//       ) as InsertChange[];
//       for (const change of changes) {
//         recorder.insertLeft(change.pos, change.toAdd);
//       }
//       host.commitUpdate(recorder)
//       const exportSource = getAsSourceFile(host, 'src/app/shared/shared.module.ts')
//       const exportRecoder = host.beginUpdate(sharedModulePath);
//       const exportChange = addExportToModule(
//         exportSource,
//         sharedModulePath,
//         classifyNameLoop,
//         importPathLoop
//       ) as InsertChange[];
//       for (const change of exportChange) {
//         if (change.path) {
//           exportRecoder.insertLeft(change.pos, change.toAdd);
//         }
//       }
//       host.commitUpdate(exportRecoder)
//       // const directiveName =  strings.classify(_option.name)
//       // const importContent = `import { ${directiveName}AutoLoopDirective } from './${''}/auto-loop-${directiveName}.directive.ts'; \n`
//       // const moduleFiles = getAsSourceFile(host, sharedModulePath)
//       // const lastImportEndPos = findlastImportEndPos(moduleFiles)
//       // const DeclarationsEndPos = findDeclarationsArray(moduleFiles)
//       // const exportEndPos = findExportArray(moduleFiles)
//       // rec.insertLeft(lastImportEndPos + 1, importContent)
//       // rec.insertLeft(DeclarationsEndPos - 1, `,${directiveName}AutoLoopDirective \n`)
//       // rec.insertLeft(exportEndPos - 1, `,${directiveName}AutoLoopDirective \n`)
//     }
//     return host
//   }
// }
// function specFilter(_options: any): Rule {
//   if (_options.skiptest) {
//     return filter(path => !path.includes('.spec.ts'))
//   }
//   return noop()
// }
// function searchFilter(_options: any): Rule {
//   if (_options.skipsearch) {
//     return filter(path => !path.includes('search-'))
//   }
//   return noop()
// }
// function autoLoopFilter(_options: any): Rule {
//   if (_options.skiploop) {
//     return filter(path => !path.includes('loop-'))
//   }
//   return noop()
// }
// function getAsSourceFile(host: Tree, path: string): ts.SourceFile {
//   const text = host.read(path);
//   if (text === null) {
//     throw new SchematicsException('dont find');
//   }
//   const sourceText = text.toString('utf-8');
//   if (!sourceText) {
//     throw new SchematicsException(`${path} not found`)
//   }
//   return ts.createSourceFile(
//     path,
//     sourceText,
//     ts.ScriptTarget.Latest,
//     true
//   )
// }
//# sourceMappingURL=index.js.map
import { Rule } from '@angular-devkit/schematics';
export declare function feature(_options: any): Rule;
